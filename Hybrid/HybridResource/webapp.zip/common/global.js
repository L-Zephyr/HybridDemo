function buttonClick() {
	alert("click at button")
}

